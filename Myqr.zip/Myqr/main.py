import qrcode as qr
img= qr.make("https://in.linkedin.com/in/deveshwarsinghrajawat")
img.save("Dev Profile.png")




